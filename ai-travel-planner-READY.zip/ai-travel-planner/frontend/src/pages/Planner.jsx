import React, { useState } from 'react';
import PlannerForm from '../components/PlannerForm';
import ItineraryCard from '../components/ItineraryCard';
import BudgetChart from '../components/BudgetChart';
import WeatherWidget from '../components/WeatherWidget';
import AlgorithmComparison from '../components/AlgorithmComparison';
import { generateItinerary } from '../services/api';

export default function Planner() {
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [lastForm, setLastForm] = useState(null);

  const handleSubmit = async (form) => {
    setLoading(true);
    setError('');
    setResult(null);
    setLastForm(form);
    try {
      const res = await generateItinerary(form);
      setResult(res.data);
      // Scroll down to results
      setTimeout(() => document.getElementById('results')?.scrollIntoView({ behavior: 'smooth' }), 100);
    } catch (err) {
      const msg = err.response?.data?.error || 'Could not connect to backend. Make sure Flask is running on port 5000.';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '2.5rem 1.5rem' }}>
      <div style={{ marginBottom: '2rem' }}>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', color: 'var(--ink)', marginBottom: '0.3rem' }}>
          AI Itinerary Planner
        </h1>
        <p style={{ color: 'var(--ink-soft)' }}>
          Using BFS, DFS & A* search algorithms to find your optimal Pakistan route
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '380px 1fr', gap: '2rem', alignItems: 'start' }}>
        {/* LEFT — Form */}
        <div style={{ position: 'sticky', top: '80px' }}>
          <PlannerForm onSubmit={handleSubmit} loading={loading} />
        </div>

        {/* RIGHT — Results */}
        <div id="results">
          {/* Error */}
          {error && (
            <div style={{
              background: '#fef2f2', border: '1px solid #fca5a5',
              color: 'var(--red)', borderRadius: 'var(--radius)',
              padding: '1rem 1.25rem', marginBottom: '1.5rem', fontSize: '0.9rem',
            }}>
              ❌ {error}
            </div>
          )}

          {/* Loading */}
          {loading && (
            <div style={{
              background: 'var(--white)', borderRadius: 'var(--radius)',
              padding: '3rem', textAlign: 'center', boxShadow: 'var(--shadow-md)',
            }}>
              <div style={{ fontSize: '2.5rem', marginBottom: '1rem', animation: 'spin 1s linear infinite' }}>✈️</div>
              <p style={{ color: 'var(--ink-soft)', fontWeight: 500 }}>
                Running {lastForm?.algorithm?.toUpperCase() || 'A*'} search algorithm…
              </p>
              <p style={{ color: 'var(--ink-soft)', fontSize: '0.85rem', marginTop: '0.3rem' }}>
                Finding optimal route from {lastForm?.start} to {lastForm?.destination}
              </p>
              <style>{`@keyframes spin { from{transform:rotate(0)} to{transform:rotate(360deg)} }`}</style>
            </div>
          )}

          {/* Results */}
          {result && !loading && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>

              {/* Route summary banner */}
              <div style={{
                background: 'linear-gradient(135deg, #0f172a, #1e3a5f)',
                color: 'var(--white)', borderRadius: 'var(--radius)',
                padding: '1.5rem',
              }}>
                <div style={{ fontSize: '0.78rem', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '0.5rem' }}>
                  Your Optimized Route
                </div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', marginBottom: '0.75rem' }}>
                  {result.route?.join(' → ')}
                </div>
                <div style={{ display: 'flex', gap: '1.5rem', flexWrap: 'wrap' }}>
                  {[
                    { label: 'Days', val: result.total_days },
                    { label: 'Travelers', val: result.travelers },
                    { label: 'Transport', val: `$${result.route_info?.estimated_transport_cost_usd || 0}` },
                    { label: 'Travel Time', val: `${result.route_info?.estimated_travel_hours || 0}h` },
                    { label: 'Algorithm', val: result.algorithm_used?.toUpperCase() },
                  ].map((s, i) => (
                    <div key={i}>
                      <div style={{ fontSize: '0.72rem', color: 'rgba(255,255,255,0.5)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{s.label}</div>
                      <div style={{ fontWeight: 700, fontSize: '1rem' }}>{s.val}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Weather row */}
              {result.route && (
                <div>
                  <div style={{ fontSize: '0.78rem', fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--ink-soft)', marginBottom: '0.5rem' }}>
                    Current Weather
                  </div>
                  <div style={{ display: 'flex', gap: '0.6rem', flexWrap: 'wrap' }}>
                    {result.route.map(city => <WeatherWidget key={city} city={city} />)}
                  </div>
                </div>
              )}

              {/* Budget chart */}
              <BudgetChart summary={result.budget_summary} />

              {/* Algorithm comparison */}
              <AlgorithmComparison comparison={result.comparison} used={result.algorithm_used} />

              {/* Day-by-day itinerary */}
              <div>
                <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', color: 'var(--ink)', marginBottom: '1rem' }}>
                  📅 Day-by-Day Itinerary
                </h3>
                {result.itinerary?.map(day => (
                  <ItineraryCard key={day.day} day={day} />
                ))}
              </div>
            </div>
          )}

          {/* Empty state */}
          {!result && !loading && !error && (
            <div style={{
              background: 'var(--white)', borderRadius: 'var(--radius)',
              padding: '4rem 2rem', textAlign: 'center', boxShadow: 'var(--shadow-sm)',
              border: '2px dashed rgba(15,23,42,0.1)',
            }}>
              <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🗺️</div>
              <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', color: 'var(--ink)', marginBottom: '0.5rem' }}>
                Your itinerary will appear here
              </h3>
              <p style={{ color: 'var(--ink-soft)', fontSize: '0.9rem' }}>
                Fill in the form and click "Generate My Itinerary"
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
