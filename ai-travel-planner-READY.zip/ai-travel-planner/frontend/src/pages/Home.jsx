import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function Home() {
  const navigate = useNavigate();
  return (
    <div style={{ maxWidth: '900px', margin: '0 auto', padding: '4rem 1.5rem', textAlign: 'center' }}>
      <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>✈️</div>
      <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '3rem', color: 'var(--ink)', marginBottom: '1rem' }}>
        AI Travel Planner
      </h1>
      <p style={{ fontSize: '1.1rem', color: 'var(--ink-soft)', marginBottom: '2.5rem', maxWidth: '600px', margin: '0 auto 2.5rem' }}>
        Plan your perfect Pakistan trip using BFS, DFS & A* search algorithms. Get optimized routes, day-by-day itineraries, and budget breakdowns instantly.
      </p>
      <button
        onClick={() => navigate('/planner')}
        style={{
          padding: '1rem 2.5rem', background: 'var(--ink)', color: 'var(--white)',
          borderRadius: '8px', fontSize: '1rem', fontWeight: 700,
          letterSpacing: '0.06em', textTransform: 'uppercase', cursor: 'pointer',
        }}
      >
        Start Planning →
      </button>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1.5rem', marginTop: '4rem' }}>
        {[
          { icon: '🧠', title: 'AI Algorithms', desc: 'BFS, DFS and A* find your optimal route automatically' },
          { icon: '📅', title: 'Day-by-Day Plan', desc: 'Full itinerary with morning, afternoon and evening activities' },
          { icon: '💰', title: 'Budget Tracker', desc: 'Hotel, food and transport costs calculated per traveler' },
        ].map((f, i) => (
          <div key={i} style={{ background: 'var(--white)', borderRadius: '12px', padding: '1.5rem', boxShadow: 'var(--shadow-sm)', textAlign: 'left' }}>
            <div style={{ fontSize: '2rem', marginBottom: '0.75rem' }}>{f.icon}</div>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.1rem', marginBottom: '0.4rem', color: 'var(--ink)' }}>{f.title}</h3>
            <p style={{ fontSize: '0.88rem', color: 'var(--ink-soft)', lineHeight: 1.6 }}>{f.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
