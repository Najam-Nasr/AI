import axios from 'axios';

const API = axios.create({ baseURL: 'http://localhost:5000' });

export const generateItinerary = (formData) =>
  API.post('/api/planner/generate', formData);

export const getCities = () =>
  API.get('/api/planner/cities');

export const getWeather = (city) =>
  API.get(`/api/weather/${city}`);

export const getAITips = (city, interests, days) =>
  API.post('/api/ai/tips', { city, interests, days });
