import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';

const styles = {
  nav: {
    position: 'sticky', top: 0, zIndex: 100,
    background: 'rgba(15,23,42,0.97)',
    backdropFilter: 'blur(12px)',
    borderBottom: '1px solid rgba(201,168,76,0.2)',
    padding: '0 2rem',
    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    height: '64px',
  },
  logo: {
    fontFamily: 'var(--font-display)',
    fontSize: '1.4rem',
    color: 'var(--gold)',
    letterSpacing: '0.02em',
  },
  logoSpan: { color: 'var(--white)' },
  links: { display: 'flex', gap: '2rem', alignItems: 'center' },
  link: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: '0.9rem',
    fontWeight: 500,
    letterSpacing: '0.04em',
    textTransform: 'uppercase',
    transition: 'color 0.2s',
  },
  linkActive: { color: 'var(--gold)' },
  btn: {
    background: 'var(--gold)',
    color: 'var(--ink)',
    padding: '0.5rem 1.2rem',
    borderRadius: '6px',
    fontSize: '0.85rem',
    fontWeight: 600,
    letterSpacing: '0.04em',
    textTransform: 'uppercase',
    transition: 'background 0.2s',
  },
};

export default function Navbar() {
  const location = useLocation();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const isActive = (path) => location.pathname === path;

  return (
    <nav style={{ ...styles.nav, boxShadow: scrolled ? '0 4px 20px rgba(0,0,0,0.4)' : 'none' }}>
      <Link to="/">
        <span style={styles.logo}>
          ✈ AI<span style={styles.logoSpan}>Travel</span>
        </span>
      </Link>
      <div style={styles.links}>
        <Link to="/" style={{ ...styles.link, ...(isActive('/') ? styles.linkActive : {}) }}>
          Home
        </Link>
        <Link to="/planner" style={{ ...styles.btn }}>
          Plan a Trip
        </Link>
      </div>
    </nav>
  );
}
