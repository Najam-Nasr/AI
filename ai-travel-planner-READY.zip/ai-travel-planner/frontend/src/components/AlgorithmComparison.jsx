import React, { useState } from 'react';

const ALGO_INFO = {
  bfs:        { label: 'BFS', color: '#3b82f6', bg: '#dbeafe', desc: 'Fewest stops — explores level by level' },
  dfs:        { label: 'DFS', color: '#10b981', bg: '#d1fae5', desc: 'Deep search — follows one path fully' },
  astar_cost: { label: 'A* Cost', color: '#c9a84c', bg: '#fef3c7', desc: 'Optimal — cheapest total route' },
  astar_time: { label: 'A* Time', color: '#8b5cf6', bg: '#ede9fe', desc: 'Optimal — fastest total route' },
};

export default function AlgorithmComparison({ comparison, used }) {
  const [show, setShow] = useState(false);
  if (!comparison) return null;

  return (
    <div style={{ background: 'var(--white)', borderRadius: 'var(--radius)', padding: '1.5rem', boxShadow: 'var(--shadow-md)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: show ? '1.25rem' : 0 }}>
        <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.2rem', color: 'var(--ink)' }}>
          🔬 Algorithm Comparison
        </h3>
        <button
          onClick={() => setShow(s => !s)}
          style={{
            background: 'var(--cream)', border: 'none', borderRadius: '6px',
            padding: '0.35rem 0.75rem', fontSize: '0.8rem', fontWeight: 600,
            color: 'var(--ink-soft)', cursor: 'pointer',
          }}
        >
          {show ? 'Hide ▲' : 'Show ▼'}
        </button>
      </div>

      {show && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {Object.entries(comparison).map(([key, algo]) => {
            const info = ALGO_INFO[key] || { label: key, color: '#64748b', bg: '#f1f5f9', desc: '' };
            const isUsed = key.startsWith(used) || (used === 'astar' && key.startsWith('astar'));
            return (
              <div key={key} style={{
                border: isUsed ? `2px solid ${info.color}` : '1.5px solid rgba(15,23,42,0.08)',
                borderRadius: '8px', padding: '0.85rem 1rem',
                background: isUsed ? info.bg : 'var(--cream)',
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.4rem' }}>
                  <span style={{ fontWeight: 700, color: info.color, fontSize: '0.85rem', letterSpacing: '0.05em' }}>
                    {info.label} {isUsed && <span style={{ fontSize: '0.7rem', background: info.color, color: '#fff', padding: '0.1rem 0.4rem', borderRadius: '100px', marginLeft: '0.3rem' }}>USED</span>}
                  </span>
                  {algo.total_cost_usd !== undefined && (
                    <span style={{ fontSize: '0.8rem', color: 'var(--ink-soft)' }}>
                      ${algo.total_cost_usd} · {algo.total_hours}h
                    </span>
                  )}
                  {algo.stops !== undefined && (
                    <span style={{ fontSize: '0.8rem', color: 'var(--ink-soft)' }}>{algo.stops} stops</span>
                  )}
                </div>
                <div style={{ fontSize: '0.82rem', color: 'var(--ink-soft)', marginBottom: '0.3rem' }}>{info.desc}</div>
                {algo.path && (
                  <div style={{ fontSize: '0.8rem', color: 'var(--ink)', fontWeight: 500 }}>
                    {algo.path.join(' → ')}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
