import React, { useState, useEffect } from 'react';
import { getCities } from '../services/api';

const INTERESTS = ['adventure', 'historical', 'cultural', 'nature', 'food'];
const HOTELS = [
  { value: 'budget', label: '🏨 Budget (Hostels & cheap hotels)' },
  { value: 'mid', label: '🏩 Mid-Range (3-star hotels)' },
  { value: 'luxury', label: '🏰 Luxury (5-star hotels)' },
];
const ALGORITHMS = [
  { value: 'astar', label: '⭐ A* (Recommended — finds optimal path)' },
  { value: 'bfs', label: '🔵 BFS (Fewest stops)' },
  { value: 'dfs', label: '🟢 DFS (Deep exploration)' },
];

const inputStyle = {
  width: '100%', padding: '0.7rem 1rem',
  border: '1.5px solid rgba(15,23,42,0.15)',
  borderRadius: '8px', fontSize: '0.95rem',
  background: 'var(--white)', color: 'var(--ink)',
  transition: 'border-color 0.2s',
};

const labelStyle = {
  display: 'block', fontSize: '0.82rem', fontWeight: 600,
  letterSpacing: '0.06em', textTransform: 'uppercase',
  color: 'var(--ink-soft)', marginBottom: '0.4rem',
};

const fieldStyle = { marginBottom: '1.25rem' };

export default function PlannerForm({ onSubmit, loading }) {
  const [cities, setCities] = useState([]);
  const [form, setForm] = useState({
    start: 'Karachi',
    destination: 'Hunza',
    days: 7,
    budget: 500,
    travelers: 2,
    hotel_pref: 'mid',
    interests: ['adventure', 'historical'],
    algorithm: 'astar',
    optimize: 'cost',
  });

  useEffect(() => {
    getCities()
      .then(r => setCities(r.data.cities))
      .catch(() => setCities(['Karachi','Lahore','Islamabad','Hunza','Swat','Skardu','Peshawar','Murree','Gilgit','Quetta','Multan','Hyderabad','Sukkur']));
  }, []);

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

  const toggleInterest = (i) => {
    const cur = form.interests;
    if (cur.includes(i)) {
      if (cur.length === 1) return; // keep at least one
      set('interests', cur.filter(x => x !== i));
    } else {
      set('interests', [...cur, i]);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (form.start === form.destination) {
      alert('Start and destination must be different cities.');
      return;
    }
    onSubmit(form);
  };

  return (
    <form onSubmit={handleSubmit} style={{ background: 'var(--white)', borderRadius: 'var(--radius)', padding: '2rem', boxShadow: 'var(--shadow-md)' }}>
      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.6rem', marginBottom: '0.25rem', color: 'var(--ink)' }}>
        Plan Your Trip
      </h2>
      <p style={{ color: 'var(--ink-soft)', fontSize: '0.88rem', marginBottom: '1.75rem' }}>
        Fill in your details and our AI will build your itinerary
      </p>

      {/* Route */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1.25rem' }}>
        <div>
          <label style={labelStyle}>From</label>
          <select style={inputStyle} value={form.start} onChange={e => set('start', e.target.value)}>
            {cities.map(c => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div>
          <label style={labelStyle}>To</label>
          <select style={inputStyle} value={form.destination} onChange={e => set('destination', e.target.value)}>
            {cities.map(c => <option key={c}>{c}</option>)}
          </select>
        </div>
      </div>

      {/* Days / Travelers / Budget */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1rem', marginBottom: '1.25rem' }}>
        <div>
          <label style={labelStyle}>Days</label>
          <input style={inputStyle} type="number" min={2} max={30} value={form.days}
            onChange={e => set('days', Number(e.target.value))} />
        </div>
        <div>
          <label style={labelStyle}>Travelers</label>
          <input style={inputStyle} type="number" min={1} max={20} value={form.travelers}
            onChange={e => set('travelers', Number(e.target.value))} />
        </div>
        <div>
          <label style={labelStyle}>Budget (USD)</label>
          <input style={inputStyle} type="number" min={50} value={form.budget}
            onChange={e => set('budget', Number(e.target.value))} />
        </div>
      </div>

      {/* Hotel */}
      <div style={fieldStyle}>
        <label style={labelStyle}>Hotel Preference</label>
        <select style={inputStyle} value={form.hotel_pref} onChange={e => set('hotel_pref', e.target.value)}>
          {HOTELS.map(h => <option key={h.value} value={h.value}>{h.label}</option>)}
        </select>
      </div>

      {/* Interests */}
      <div style={fieldStyle}>
        <label style={labelStyle}>Interests (pick at least one)</label>
        <div style={{ display: 'flex', gap: '0.6rem', flexWrap: 'wrap' }}>
          {INTERESTS.map(i => {
            const active = form.interests.includes(i);
            return (
              <button key={i} type="button" onClick={() => toggleInterest(i)} style={{
                padding: '0.45rem 1rem', borderRadius: '100px', fontSize: '0.85rem',
                fontWeight: 600, letterSpacing: '0.03em', textTransform: 'capitalize',
                border: active ? '1.5px solid var(--teal)' : '1.5px solid rgba(15,23,42,0.15)',
                background: active ? 'var(--teal-light)' : 'var(--white)',
                color: active ? 'var(--teal)' : 'var(--ink-soft)',
                transition: 'all 0.15s',
              }}>{i}</button>
            );
          })}
        </div>
      </div>

      {/* Algorithm */}
      <div style={fieldStyle}>
        <label style={labelStyle}>Search Algorithm</label>
        <select style={inputStyle} value={form.algorithm} onChange={e => set('algorithm', e.target.value)}>
          {ALGORITHMS.map(a => <option key={a.value} value={a.value}>{a.label}</option>)}
        </select>
      </div>

      {/* Optimize — only show for A* */}
      {form.algorithm === 'astar' && (
        <div style={fieldStyle}>
          <label style={labelStyle}>Optimize For</label>
          <div style={{ display: 'flex', gap: '0.75rem' }}>
            {['cost', 'time'].map(opt => (
              <button key={opt} type="button" onClick={() => set('optimize', opt)} style={{
                flex: 1, padding: '0.6rem', borderRadius: '8px', fontSize: '0.9rem', fontWeight: 600,
                border: form.optimize === opt ? '2px solid var(--gold)' : '1.5px solid rgba(15,23,42,0.15)',
                background: form.optimize === opt ? 'rgba(201,168,76,0.1)' : 'var(--white)',
                color: form.optimize === opt ? '#92700a' : 'var(--ink-soft)',
                transition: 'all 0.15s',
              }}>
                {opt === 'cost' ? '💰 Lowest Cost' : '⚡ Fastest Time'}
              </button>
            ))}
          </div>
        </div>
      )}

      <button type="submit" disabled={loading} style={{
        width: '100%', padding: '0.9rem',
        background: loading ? 'var(--ink-soft)' : 'var(--ink)',
        color: 'var(--white)', borderRadius: '8px',
        fontSize: '0.95rem', fontWeight: 700, letterSpacing: '0.06em',
        textTransform: 'uppercase', transition: 'background 0.2s',
        marginTop: '0.5rem',
      }}>
        {loading ? '🔄 Generating Itinerary…' : '✈ Generate My Itinerary'}
      </button>
    </form>
  );
}
