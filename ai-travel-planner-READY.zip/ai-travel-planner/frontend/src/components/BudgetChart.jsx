import React from 'react';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const COLORS = ['#0d9488', '#c9a84c', '#1e3a5f'];

export default function BudgetChart({ summary }) {
  if (!summary) return null;

  const data = [
    { name: 'Hotels', value: summary.hotel_total },
    { name: 'Food', value: summary.food_total },
    { name: 'Transport', value: summary.transport_total },
  ];

  const over = summary.status === 'over_budget';

  return (
    <div style={{ background: 'var(--white)', borderRadius: 'var(--radius)', padding: '1.75rem', boxShadow: 'var(--shadow-md)' }}>
      <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.3rem', marginBottom: '1.25rem', color: 'var(--ink)' }}>
        💰 Budget Breakdown
      </h3>

      <ResponsiveContainer width="100%" height={220}>
        <PieChart>
          <Pie data={data} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
            {data.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}
          </Pie>
          <Tooltip formatter={(v) => `$${v}`} />
          <Legend />
        </PieChart>
      </ResponsiveContainer>

      {/* Summary rows */}
      <div style={{ marginTop: '1rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
        {data.map((d, i) => (
          <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.5rem 0.75rem', background: 'var(--cream)', borderRadius: '6px' }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.9rem', color: 'var(--ink-soft)' }}>
              <span style={{ width: '10px', height: '10px', borderRadius: '50%', background: COLORS[i], display: 'inline-block' }} />
              {d.name}
            </span>
            <strong style={{ fontSize: '0.95rem', color: 'var(--ink)' }}>${d.value}</strong>
          </div>
        ))}

        <div style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          padding: '0.65rem 0.75rem',
          background: over ? '#fef2f2' : '#f0fdf4',
          borderRadius: '6px', marginTop: '0.25rem',
          border: `1.5px solid ${over ? '#fca5a5' : '#86efac'}`,
        }}>
          <strong style={{ fontSize: '0.95rem', color: 'var(--ink)' }}>Total</strong>
          <div style={{ textAlign: 'right' }}>
            <strong style={{ fontSize: '1.1rem', color: over ? 'var(--red)' : 'var(--teal)' }}>
              ${summary.grand_total}
            </strong>
            <div style={{ fontSize: '0.78rem', color: 'var(--ink-soft)' }}>
              Budget: ${summary.budget}
            </div>
          </div>
        </div>

        {over && (
          <div style={{ background: '#fef2f2', border: '1px solid #fca5a5', color: 'var(--red)', borderRadius: '6px', padding: '0.5rem 0.75rem', fontSize: '0.85rem' }}>
            ⚠️ Over budget by ${summary.over_by}. Try budget hotels or fewer days.
          </div>
        )}
        {!over && (
          <div style={{ background: '#f0fdf4', border: '1px solid #86efac', color: '#166534', borderRadius: '6px', padding: '0.5rem 0.75rem', fontSize: '0.85rem' }}>
            ✅ Within budget! You have ${summary.budget - summary.grand_total} to spare.
          </div>
        )}
      </div>
    </div>
  );
}
