import React, { useEffect, useState } from 'react';
import { getWeather } from '../services/api';

const CONDITION_ICON = {
  'Sunny': '☀️', 'Clear': '🌤️', 'Partly Cloudy': '⛅',
  'Cloudy': '☁️', 'Rain': '🌧️', 'Foggy': '🌫️', 'Hot': '🔥',
};

export default function WeatherWidget({ city }) {
  const [weather, setWeather] = useState(null);

  useEffect(() => {
    if (!city) return;
    getWeather(city)
      .then(r => setWeather(r.data))
      .catch(() => {});
  }, [city]);

  if (!weather) return null;

  const icon = CONDITION_ICON[weather.condition] || '🌡️';

  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: '0.6rem',
      background: 'rgba(13,148,136,0.08)',
      border: '1px solid rgba(13,148,136,0.2)',
      borderRadius: '8px', padding: '0.5rem 0.85rem',
      fontSize: '0.85rem',
    }}>
      <span style={{ fontSize: '1.3rem' }}>{icon}</span>
      <div>
        <div style={{ fontWeight: 600, color: 'var(--ink)' }}>{city}</div>
        <div style={{ color: 'var(--ink-soft)' }}>
          {weather.temp}°C · {weather.condition} · 💧{weather.humidity}%
        </div>
      </div>
    </div>
  );
}
