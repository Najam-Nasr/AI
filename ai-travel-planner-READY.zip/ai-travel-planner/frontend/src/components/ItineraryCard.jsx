import React, { useState } from 'react';

const TIME_SLOTS = [
  { key: 'morning', label: '🌅 Morning', color: '#fef3c7', border: '#fbbf24' },
  { key: 'afternoon', label: '☀️ Afternoon', color: '#dbeafe', border: '#60a5fa' },
  { key: 'evening', label: '🌙 Evening', color: '#ede9fe', border: '#a78bfa' },
];

export default function ItineraryCard({ day }) {
  const [open, setOpen] = useState(day.day <= 2);

  return (
    <div style={{
      background: 'var(--white)', borderRadius: 'var(--radius)',
      border: '1px solid rgba(15,23,42,0.08)',
      boxShadow: 'var(--shadow-sm)', overflow: 'hidden',
      marginBottom: '0.75rem',
      transition: 'box-shadow 0.2s',
    }}>
      {/* Header — always visible, click to expand */}
      <button
        onClick={() => setOpen(o => !o)}
        style={{
          width: '100%', background: 'none', border: 'none',
          padding: '1rem 1.25rem', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          textAlign: 'left',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <div style={{
            width: '36px', height: '36px', borderRadius: '50%',
            background: 'var(--ink)', color: 'var(--gold)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontWeight: 700, fontSize: '0.85rem', flexShrink: 0,
          }}>
            {day.day}
          </div>
          <div>
            <div style={{ fontWeight: 600, fontSize: '1rem', color: 'var(--ink)' }}>
              Day {day.day} — {day.city}
            </div>
            <div style={{ fontSize: '0.8rem', color: 'var(--ink-soft)' }}>
              Hotel ${day.hotel_cost} + Food ${day.food_cost} = <strong>${day.day_total}</strong>
            </div>
          </div>
        </div>
        <span style={{ color: 'var(--ink-soft)', fontSize: '1.1rem', transition: 'transform 0.2s', transform: open ? 'rotate(180deg)' : 'rotate(0deg)' }}>
          ▼
        </span>
      </button>

      {/* Expanded body */}
      {open && (
        <div style={{ padding: '0 1.25rem 1.25rem', borderTop: '1px solid rgba(15,23,42,0.06)' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem', marginTop: '1rem' }}>
            {TIME_SLOTS.map(slot => (
              <div key={slot.key} style={{
                background: slot.color,
                border: `1px solid ${slot.border}`,
                borderRadius: '8px', padding: '0.65rem 1rem',
                display: 'flex', gap: '0.75rem', alignItems: 'flex-start',
              }}>
                <span style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--ink-soft)', minWidth: '80px', paddingTop: '1px' }}>
                  {slot.label}
                </span>
                <span style={{ fontSize: '0.9rem', color: 'var(--ink)' }}>
                  {day[slot.key] || 'Free time / explore at your own pace'}
                </span>
              </div>
            ))}
          </div>

          {/* All activities */}
          {day.activities && day.activities.length > 0 && (
            <div style={{ marginTop: '0.75rem' }}>
              <div style={{ fontSize: '0.78rem', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--ink-soft)', marginBottom: '0.4rem' }}>
                All Activities
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
                {day.activities.map((a, i) => (
                  <span key={i} style={{
                    background: 'var(--cream)', color: 'var(--ink)',
                    padding: '0.25rem 0.65rem', borderRadius: '100px',
                    fontSize: '0.8rem', border: '1px solid rgba(15,23,42,0.1)',
                  }}>
                    {a}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
