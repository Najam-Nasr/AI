# AI Travel Planner
**Flask + React | BFS · DFS · A* Search Algorithms**

---

## Folder Structure

```
ai-travel-planner/
├── backend/
│   ├── app.py                  ← Flask entry point
│   ├── config.py               ← Reads API keys from .env
│   ├── requirements.txt        ← Python packages
│   ├── .env                    ← Your API keys (never share this)
│   ├── ai/
│   │   ├── graph_data.py       ← Pakistan city graph + attractions
│   │   ├── search_algorithms.py ← BFS, DFS, A* algorithms
│   │   └── itinerary_generator.py ← Builds day-by-day plan
│   ├── routes/
│   │   ├── planner.py          ← POST /api/planner/generate
│   │   ├── weather.py          ← GET /api/weather/<city>
│   │   └── ai_recommend.py     ← POST /api/ai/tips
│   └── tests/
│       └── test_algorithms.py  ← Test BFS/DFS/A* without Flask
└── frontend/
    ├── package.json
    └── src/
        ├── App.js
        ├── index.js
        ├── index.css
        ├── services/api.js     ← All axios calls to Flask
        ├── components/
        │   ├── Navbar.jsx
        │   ├── PlannerForm.jsx
        │   ├── ItineraryCard.jsx
        │   ├── BudgetChart.jsx
        │   ├── WeatherWidget.jsx
        │   └── AlgorithmComparison.jsx
        └── pages/
            ├── Home.jsx
            └── Planner.jsx
```

---

## HOW TO RUN (Step by Step)

### Step 1 — Set up the Backend

Open a terminal. Go into the backend folder:
```
cd ai-travel-planner/backend
```

Create a Python virtual environment:
```
python -m venv venv
```

Activate it:
- Windows:  `venv\Scripts\activate`
- Mac/Linux: `source venv/bin/activate`

Install packages:
```
pip install -r requirements.txt
```

Copy the env template to .env:
```
copy .env.template .env        (Windows)
cp .env.template .env          (Mac/Linux)
```

Edit `.env` and add your API keys (or leave as-is — mock data works fine without real keys).

### Step 2 — Test the AI Algorithms (optional but recommended)
```
python tests/test_algorithms.py
```
You should see BFS, DFS, A* results printed. If this works, your backend logic is correct.

### Step 3 — Start the Flask Backend
```
python app.py
```
You should see:  `Running on http://127.0.0.1:5000`
Keep this terminal open.

### Step 4 — Set up the Frontend

Open a SECOND terminal window. Go into the frontend folder:
```
cd ai-travel-planner/frontend
```

Install React packages:
```
npm install
```

Start React:
```
npm start
```
Browser opens automatically at `http://localhost:3000`

---

## Using the App

1. Go to `http://localhost:3000`
2. Click **"Plan a Trip"** in the navbar
3. Choose your start city, destination, days, budget, interests
4. Select an algorithm (A* is best)
5. Click **"Generate My Itinerary"**
6. See your route, day-by-day plan, budget chart, weather, and algorithm comparison

---

## API Keys (Optional)

Without keys, the app uses **mock data** and still works fully.

| Key | Where to get | What it does |
|-----|-------------|--------------|
| OPENWEATHER_API_KEY | openweathermap.org/api | Real weather data |
| OPENAI_API_KEY | platform.openai.com | GPT travel tips |
| GOOGLE_MAPS_API_KEY | console.cloud.google.com | Map embeds |

---

## Test the API with curl

```bash
curl -X POST http://localhost:5000/api/planner/generate \
  -H "Content-Type: application/json" \
  -d "{\"start\":\"Karachi\",\"destination\":\"Hunza\",\"days\":7,\"budget\":500,\"travelers\":2,\"hotel_pref\":\"mid\",\"interests\":[\"adventure\",\"historical\"],\"optimize\":\"cost\",\"algorithm\":\"astar\"}"
```
