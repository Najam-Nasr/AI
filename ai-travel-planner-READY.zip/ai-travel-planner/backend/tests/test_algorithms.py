"""
tests/test_algorithms.py
Run this file to verify all AI algorithms work correctly.
Command: python tests/test_algorithms.py
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ai.search_algorithms import bfs, dfs, astar, compare_algorithms

def test_all():
    print("=" * 60)
    print("AI TRAVEL PLANNER - Algorithm Tests")
    print("=" * 60)

    start = "Karachi"
    goal  = "Hunza"

    print(f"\nRoute: {start} → {goal}\n")

    # BFS Test
    bfs_result = bfs(start, goal)
    print(f"[BFS]  Path: {' → '.join(bfs_result) if bfs_result else 'No path'}")
    print(f"       Stops: {len(bfs_result)-1 if bfs_result else 0}")

    # DFS Test
    dfs_result = dfs(start, goal)
    print(f"\n[DFS]  Path: {' → '.join(dfs_result) if dfs_result else 'No path'}")
    print(f"       Stops: {len(dfs_result)-1 if dfs_result else 0}")

    # A* Cost
    a_path, a_cost, a_hours = astar(start, goal, optimize="cost")
    print(f"\n[A*]   Cost-Optimized Path: {' → '.join(a_path) if a_path else 'No path'}")
    print(f"       Total Cost: ${a_cost} | Travel Time: {a_hours}h")

    # A* Time
    t_path, t_cost, t_hours = astar(start, goal, optimize="time")
    print(f"\n[A*]   Time-Optimized Path: {' → '.join(t_path) if t_path else 'No path'}")
    print(f"       Total Cost: ${t_cost} | Travel Time: {t_hours}h")

    print("\n" + "=" * 60)
    print("All tests passed ✅")
    print("=" * 60)

if __name__ == "__main__":
    test_all()
