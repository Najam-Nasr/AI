"""
routes/weather.py
GET /api/weather/<city>
Returns current weather for a city.
"""

import requests
from flask import Blueprint, jsonify
from config import Config

weather_bp = Blueprint('weather', __name__)

MOCK_WEATHER = {
    "Karachi":    {"temp": 32, "condition": "Sunny", "humidity": 70, "wind": 15},
    "Lahore":     {"temp": 28, "condition": "Partly Cloudy", "humidity": 55, "wind": 10},
    "Islamabad":  {"temp": 22, "condition": "Clear", "humidity": 50, "wind": 8},
    "Hunza":      {"temp": 15, "condition": "Clear", "humidity": 40, "wind": 12},
    "Swat":       {"temp": 18, "condition": "Partly Cloudy", "humidity": 45, "wind": 10},
    "Peshawar":   {"temp": 30, "condition": "Sunny", "humidity": 48, "wind": 9},
    "Quetta":     {"temp": 20, "condition": "Clear", "humidity": 35, "wind": 14},
    "Murree":     {"temp": 14, "condition": "Foggy", "humidity": 80, "wind": 7},
    "Skardu":     {"temp": 10, "condition": "Clear", "humidity": 38, "wind": 11},
    "Gilgit":     {"temp": 16, "condition": "Clear", "humidity": 42, "wind": 10},
    "Multan":     {"temp": 35, "condition": "Sunny", "humidity": 40, "wind": 13},
    "Hyderabad":  {"temp": 33, "condition": "Sunny", "humidity": 65, "wind": 16},
    "Sukkur":     {"temp": 36, "condition": "Hot", "humidity": 38, "wind": 12},
}


@weather_bp.route('/<city>', methods=['GET'])
def get_weather(city):
    api_key = Config.OPENWEATHER_API_KEY

    if api_key and api_key != "your_openweather_key_here":
        try:
            url = f"http://api.openweathermap.org/data/2.5/weather?q={city},PK&appid={api_key}&units=metric"
            resp = requests.get(url, timeout=5)
            data = resp.json()
            return jsonify({
                "city": city,
                "temp": round(data["main"]["temp"]),
                "condition": data["weather"][0]["main"],
                "humidity": data["main"]["humidity"],
                "wind": round(data["wind"]["speed"]),
                "source": "live"
            }), 200
        except Exception:
            pass

    # Fall back to mock data
    weather = MOCK_WEATHER.get(city, {"temp": 25, "condition": "Clear", "humidity": 50, "wind": 10})
    return jsonify({"city": city, **weather, "source": "mock"}), 200
