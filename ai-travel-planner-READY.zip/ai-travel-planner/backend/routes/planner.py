"""
routes/planner.py
Main API route: POST /api/planner/generate
"""

from flask import Blueprint, request, jsonify
from ai.search_algorithms import astar, compare_algorithms
from ai.itinerary_generator import generate_itinerary

planner_bp = Blueprint('planner', __name__)


@planner_bp.route('/generate', methods=['POST'])
def generate():
    data = request.get_json()

    # Validate required fields
    required = ['start', 'destination', 'days', 'budget', 'travelers']
    for field in required:
        if field not in data:
            return jsonify({"error": f"Missing field: {field}"}), 400

    start       = data['start']
    destination = data['destination']
    days        = int(data['days'])
    budget      = float(data['budget'])
    travelers   = int(data['travelers'])
    hotel_pref  = data.get('hotel_pref', 'mid')
    interests   = data.get('interests', ['cultural'])
    algorithm   = data.get('algorithm', 'astar')
    optimize    = data.get('optimize', 'cost')

    # Run the selected algorithm
    if algorithm == 'astar':
        route, cost, hours = astar(start, destination, optimize=optimize)
    else:
        from ai.search_algorithms import bfs, dfs
        route = bfs(start, destination) if algorithm == 'bfs' else dfs(start, destination)
        cost, hours = 0, 0

    if not route:
        return jsonify({"error": f"No route found from {start} to {destination}"}), 404

    # Generate the itinerary
    result = generate_itinerary(route, days, travelers, hotel_pref, interests, budget)

    # Add algorithm comparison
    result['algorithm_used'] = algorithm
    result['route_info'] = {
        "path": route,
        "estimated_transport_cost_usd": cost,
        "estimated_travel_hours": hours,
    }
    result['comparison'] = compare_algorithms(start, destination)

    return jsonify(result), 200


@planner_bp.route('/cities', methods=['GET'])
def get_cities():
    from ai.graph_data import TRAVEL_GRAPH
    return jsonify({"cities": sorted(list(TRAVEL_GRAPH.keys()))}), 200
