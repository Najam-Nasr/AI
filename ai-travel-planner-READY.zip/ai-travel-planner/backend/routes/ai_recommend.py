"""
routes/ai_recommend.py
POST /api/ai/tips  — travel tips using OpenAI GPT
"""

import json
from flask import Blueprint, request, jsonify
from config import Config

ai_bp = Blueprint('ai', __name__)

MOCK_TIPS = {
    "Hunza":     "Hunza is best visited April–October. Carry warm clothes even in summer. Try Hunzai apricot jam and glacier water.",
    "Lahore":    "Visit Lahore Fort and Badshahi Mosque early morning to avoid crowds. Don't miss Gawalmandi food street at night.",
    "Islamabad": "Islamabad is safe and clean. Hike Margalla Hills Trail 3 for city views. Monal Restaurant offers amazing food with a view.",
    "Karachi":   "Karachi is vibrant and coastal. Visit Do Darya at sunset. The city never sleeps — Burns Road food is best after 10pm.",
    "Swat":      "Swat valley is breathtaking. Kalam and Mahodand Lake are must-visits. Roads can be rough — hire a local jeep.",
    "Skardu":    "Skardu is the gateway to K2. Acclimatize for a day before trekking. Shangrila resort is a hidden gem.",
    "default":   "Pakistan is a hidden gem for travel. Always carry cash in remote areas. Respect local customs and dress modestly.",
}


@ai_bp.route('/tips', methods=['POST'])
def get_tips():
    data = request.get_json()
    city = data.get('city', '')
    interests = data.get('interests', [])
    days = data.get('days', 3)

    api_key = Config.OPENAI_API_KEY

    if api_key and api_key != "your_openai_key_here":
        try:
            import openai
            client = openai.OpenAI(api_key=api_key)
            prompt = (
                f"Give 3 practical travel tips for {city}, Pakistan. "
                f"The traveler is interested in {', '.join(interests)} and staying {days} days. "
                f"Keep it short, specific, and useful."
            )
            response = client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=200
            )
            tips = response.choices[0].message.content
            return jsonify({"city": city, "tips": tips, "source": "openai"}), 200
        except Exception:
            pass

    # Fallback to mock tips
    tips = MOCK_TIPS.get(city, MOCK_TIPS["default"])
    return jsonify({"city": city, "tips": tips, "source": "mock"}), 200
