"""
ai/graph_data.py
Travel graph for Pakistan cities.
Each edge: (neighbor, cost_USD, travel_hours)
"""

TRAVEL_GRAPH = {
    "Karachi": [
        ("Hyderabad", 15, 2),
        ("Sukkur", 40, 6),
        ("Quetta", 80, 12),
    ],
    "Hyderabad": [
        ("Karachi", 15, 2),
        ("Sukkur", 30, 4),
        ("Multan", 60, 8),
    ],
    "Sukkur": [
        ("Hyderabad", 30, 4),
        ("Multan", 35, 5),
        ("Quetta", 60, 9),
    ],
    "Multan": [
        ("Hyderabad", 60, 8),
        ("Sukkur", 35, 5),
        ("Lahore", 25, 4),
        ("Islamabad", 40, 6),
    ],
    "Lahore": [
        ("Multan", 25, 4),
        ("Islamabad", 30, 4),
        ("Peshawar", 45, 5),
    ],
    "Islamabad": [
        ("Lahore", 30, 4),
        ("Peshawar", 20, 2),
        ("Gilgit", 60, 10),
        ("Murree", 10, 1),
        ("Multan", 40, 6),
    ],
    "Peshawar": [
        ("Islamabad", 20, 2),
        ("Lahore", 45, 5),
        ("Swat", 25, 3),
    ],
    "Swat": [
        ("Peshawar", 25, 3),
        ("Gilgit", 50, 8),
    ],
    "Gilgit": [
        ("Islamabad", 60, 10),
        ("Swat", 50, 8),
        ("Hunza", 20, 2),
        ("Skardu", 40, 6),
    ],
    "Hunza": [
        ("Gilgit", 20, 2),
        ("Skardu", 50, 7),
    ],
    "Skardu": [
        ("Gilgit", 40, 6),
        ("Hunza", 50, 7),
    ],
    "Murree": [
        ("Islamabad", 10, 1),
        ("Lahore", 35, 4),
    ],
    "Quetta": [
        ("Karachi", 80, 12),
        ("Sukkur", 60, 9),
    ],
}

CITY_INFO = {
    "Karachi": {
        "attractions": {
            "adventure":   ["Clifton Beach", "Port Grand", "French Beach"],
            "historical":  ["Mohatta Palace", "Quaid-e-Azam House", "Frere Hall"],
            "cultural":    ["National Museum", "Empress Market", "Saddar Bazaar"],
            "nature":      ["Karachi Zoo", "Safari Park", "Hawks Bay"],
            "food":        ["Burns Road Food Street", "Do Darya", "Boat Basin"],
        },
        "hotel_cost": {"budget": 20, "mid": 50, "luxury": 150},
        "food_cost_per_day": 15,
        "coordinates": {"lat": 24.8607, "lng": 67.0011},
    },
    "Lahore": {
        "attractions": {
            "adventure":   ["Joyland Amusement Park", "Packages Mall Ice Rink"],
            "historical":  ["Lahore Fort", "Badshahi Mosque", "Shalimar Gardens"],
            "cultural":    ["Anarkali Bazaar", "Walled City", "Lahore Museum"],
            "nature":      ["Jallo Park", "Race Course Park"],
            "food":        ["Gawalmandi Food Street", "Liberty Market", "Cafe Aylanto"],
        },
        "hotel_cost": {"budget": 25, "mid": 60, "luxury": 180},
        "food_cost_per_day": 18,
        "coordinates": {"lat": 31.5204, "lng": 74.3587},
    },
    "Islamabad": {
        "attractions": {
            "adventure":   ["Margalla Hills Hiking", "Rawal Lake", "Pir Sohawa"],
            "historical":  ["Faisal Mosque", "Pakistan Monument", "Lok Virsa Museum"],
            "cultural":    ["Shakarparian", "Centaurus Mall", "F-7 Jinnah Super"],
            "nature":      ["Margalla Hills National Park", "Rose & Jasmine Garden"],
            "food":        ["Kohsar Market", "F-6 Markaz", "Monal Restaurant"],
        },
        "hotel_cost": {"budget": 30, "mid": 70, "luxury": 200},
        "food_cost_per_day": 20,
        "coordinates": {"lat": 33.6844, "lng": 73.0479},
    },
    "Hunza": {
        "attractions": {
            "adventure":   ["Attabad Lake Boating", "Eagle's Nest Hike", "Ultar Sar Trek"],
            "historical":  ["Baltit Fort", "Altit Fort", "Ganish Village"],
            "cultural":    ["Karimabad Bazaar", "Hunza Cultural Festival"],
            "nature":      ["Rakaposhi View Point", "Attabad Lake", "Cherry Blossom Gardens"],
            "food":        ["Hunza Food Street", "Traditional Hunzai Cuisine"],
        },
        "hotel_cost": {"budget": 15, "mid": 40, "luxury": 120},
        "food_cost_per_day": 12,
        "coordinates": {"lat": 36.3167, "lng": 74.6500},
    },
    "Gilgit": {
        "attractions": {
            "adventure":   ["Naltar Valley Trek", "Gilgit River Rafting"],
            "historical":  ["Kargah Buddha", "Gilgit Fort"],
            "cultural":    ["Gilgit Bazaar", "Regional Museum"],
            "nature":      ["Naltar Lake", "Jutial Nullah"],
            "food":        ["Gilgit Food Street", "Local Dhabas"],
        },
        "hotel_cost": {"budget": 15, "mid": 35, "luxury": 100},
        "food_cost_per_day": 10,
        "coordinates": {"lat": 35.9208, "lng": 74.3083},
    },
    "Peshawar": {
        "attractions": {
            "adventure":   ["Khyber Pass Tour", "Hayatabad Sports Complex"],
            "historical":  ["Peshawar Museum", "Bala Hisar Fort", "Mahabat Khan Mosque"],
            "cultural":    ["Qissa Khwani Bazaar", "Namak Mandi"],
            "nature":      ["Warsak Dam", "University Town Parks"],
            "food":        ["Namak Mandi Charsi Tikka", "Qissa Khwani Food"],
        },
        "hotel_cost": {"budget": 20, "mid": 45, "luxury": 130},
        "food_cost_per_day": 14,
        "coordinates": {"lat": 34.0151, "lng": 71.5249},
    },
    "Swat": {
        "attractions": {
            "adventure":   ["Malam Jabba Skiing", "Ushu Forest Trek", "Mahodand Lake"],
            "historical":  ["Butkara Stupa", "Udegram Archaeological Site"],
            "cultural":    ["Mingora Bazaar", "Swat Museum"],
            "nature":      ["Kalam Valley", "Mahodand Lake", "Ushu Forest"],
            "food":        ["Mingora Food Street", "Kalam Riverside Cafes"],
        },
        "hotel_cost": {"budget": 15, "mid": 35, "luxury": 100},
        "food_cost_per_day": 10,
        "coordinates": {"lat": 35.2227, "lng": 72.4258},
    },
    "Skardu": {
        "attractions": {
            "adventure":   ["K2 Base Camp Trek", "Deosai Plains", "Shangrila Resort"],
            "historical":  ["Skardu Fort", "Kharpocho Fort"],
            "cultural":    ["Skardu Bazaar", "Local Balti Culture"],
            "nature":      ["Shangrila Lake", "Satpara Lake", "Deosai National Park"],
            "food":        ["Skardu Food Street", "Local Balti Cuisine"],
        },
        "hotel_cost": {"budget": 15, "mid": 40, "luxury": 120},
        "food_cost_per_day": 12,
        "coordinates": {"lat": 35.2971, "lng": 75.6333},
    },
    "Murree": {
        "attractions": {
            "adventure":   ["Patriata Chair Lift", "Pindi Point", "Kashmir Point Trek"],
            "historical":  ["Murree Church", "GPO Murree"],
            "cultural":    ["Mall Road", "Murree Brewery"],
            "nature":      ["Ayubia National Park", "Bhurban Valley"],
            "food":        ["Mall Road Food Stalls", "Hotel Cecil Restaurant"],
        },
        "hotel_cost": {"budget": 20, "mid": 50, "luxury": 150},
        "food_cost_per_day": 15,
        "coordinates": {"lat": 33.9071, "lng": 73.3943},
    },
    "Multan": {
        "attractions": {
            "adventure":   ["Chenab River Activities"],
            "historical":  ["Shah Rukn-e-Alam Shrine", "Multan Fort", "Shahi Eid Gah"],
            "cultural":    ["Hussain Agahi Bazaar", "Crafts Village"],
            "nature":      ["Qila Kohna Qasim Bagh", "Company Bagh"],
            "food":        ["Multan Sohan Halwa", "Chowk Bazaar Food"],
        },
        "hotel_cost": {"budget": 18, "mid": 40, "luxury": 110},
        "food_cost_per_day": 12,
        "coordinates": {"lat": 30.1575, "lng": 71.5249},
    },
    "Quetta": {
        "attractions": {
            "adventure":   ["Hanna Lake", "Urak Valley"],
            "historical":  ["Quetta Museum", "Hazarganji-Chiltan National Park"],
            "cultural":    ["Liaquat Bazaar", "Kandahari Bazaar"],
            "nature":      ["Hanna Lake", "Hazarganji Chiltan National Park"],
            "food":        ["Quetta Sajji", "Jinnah Road Food"],
        },
        "hotel_cost": {"budget": 15, "mid": 35, "luxury": 100},
        "food_cost_per_day": 10,
        "coordinates": {"lat": 30.1798, "lng": 66.9750},
    },
    "Hyderabad": {
        "attractions": {
            "adventure":   ["Indus River Activities"],
            "historical":  ["Hyderabad Fort", "Pakka Qila"],
            "cultural":    ["Shahi Bazaar", "Hyderabad Museum"],
            "nature":      ["Phuleli Canal", "Hyderabad Zoo"],
            "food":        ["Hyderabad Biryani Street", "Hirabad Food"],
        },
        "hotel_cost": {"budget": 12, "mid": 30, "luxury": 80},
        "food_cost_per_day": 10,
        "coordinates": {"lat": 25.3960, "lng": 68.3578},
    },
    "Sukkur": {
        "attractions": {
            "adventure":   ["Indus River Boat Ride"],
            "historical":  ["Sukkur Barrage", "Sadh Belo Temple", "Lansdowne Bridge"],
            "cultural":    ["Sukkur Bazaar"],
            "nature":      ["Indus River Banks"],
            "food":        ["Sukkur Local Cuisine"],
        },
        "hotel_cost": {"budget": 12, "mid": 28, "luxury": 75},
        "food_cost_per_day": 9,
        "coordinates": {"lat": 27.7052, "lng": 68.8574},
    },
}
