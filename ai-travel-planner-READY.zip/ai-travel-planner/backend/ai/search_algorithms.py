"""
ai/search_algorithms.py
BFS, DFS, and A* search algorithms for finding travel routes.
"""

import heapq
from collections import deque
from .graph_data import TRAVEL_GRAPH


def bfs(start, goal):
    """
    Breadth-First Search — finds path with fewest stops (hops).
    Returns: list of cities from start to goal, or None if no path.
    """
    if start not in TRAVEL_GRAPH or goal not in TRAVEL_GRAPH:
        return None

    queue = deque([[start]])
    visited = {start}

    while queue:
        path = queue.popleft()
        current = path[-1]

        if current == goal:
            return path

        for neighbor, cost, hours in TRAVEL_GRAPH.get(current, []):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(path + [neighbor])

    return None


def dfs(start, goal, visited=None, path=None):
    """
    Depth-First Search — explores deep routes first.
    Returns: first valid path found (not necessarily shortest).
    """
    if visited is None:
        visited = set()
    if path is None:
        path = []

    if start not in TRAVEL_GRAPH or goal not in TRAVEL_GRAPH:
        return None

    visited.add(start)
    path = path + [start]

    if start == goal:
        return path

    for neighbor, cost, hours in TRAVEL_GRAPH.get(start, []):
        if neighbor not in visited:
            result = dfs(neighbor, goal, visited, path)
            if result:
                return result

    return None


def astar(start, goal, optimize="cost"):
    """
    A* Search — finds the optimal path by cost or time.
    optimize: "cost" (minimize USD) or "time" (minimize hours)
    Returns: (path, total_cost, total_hours)
    """
    if start not in TRAVEL_GRAPH or goal not in TRAVEL_GRAPH:
        return None, 0, 0

    # Priority queue: (f_score, g_score, city, path)
    heap = [(0, 0, start, [start])]
    visited = {}

    while heap:
        f, g, current, path = heapq.heappop(heap)

        if current in visited:
            continue
        visited[current] = g

        if current == goal:
            # Calculate totals
            total_cost = 0
            total_hours = 0
            for i in range(len(path) - 1):
                city_a = path[i]
                city_b = path[i + 1]
                for neighbor, c, h in TRAVEL_GRAPH.get(city_a, []):
                    if neighbor == city_b:
                        total_cost += c
                        total_hours += h
                        break
            return path, total_cost, total_hours

        for neighbor, cost, hours in TRAVEL_GRAPH.get(current, []):
            if neighbor not in visited:
                step = cost if optimize == "cost" else hours
                new_g = g + step
                # Simple heuristic: 0 (makes it Dijkstra-like, still optimal)
                h = 0
                new_f = new_g + h
                heapq.heappush(heap, (new_f, new_g, neighbor, path + [neighbor]))

    return None, 0, 0


def compare_algorithms(start, goal):
    """
    Runs all algorithms and returns a comparison dictionary.
    """
    bfs_path = bfs(start, goal)
    dfs_path = dfs(start, goal)
    astar_cost_path, astar_cost, astar_hours = astar(start, goal, optimize="cost")
    astar_time_path, astar_time_cost, astar_time_hours = astar(start, goal, optimize="time")

    return {
        "bfs": {
            "algorithm": "BFS (Breadth-First Search)",
            "path": bfs_path,
            "stops": len(bfs_path) - 1 if bfs_path else 0,
            "description": "Fewest number of stops"
        },
        "dfs": {
            "algorithm": "DFS (Depth-First Search)",
            "path": dfs_path,
            "stops": len(dfs_path) - 1 if dfs_path else 0,
            "description": "Explores deep routes first"
        },
        "astar_cost": {
            "algorithm": "A* (Cost Optimized)",
            "path": astar_cost_path,
            "total_cost_usd": astar_cost,
            "total_hours": astar_hours,
            "description": "Minimum travel cost"
        },
        "astar_time": {
            "algorithm": "A* (Time Optimized)",
            "path": astar_time_path,
            "total_cost_usd": astar_time_cost,
            "total_hours": astar_time_hours,
            "description": "Minimum travel time"
        }
    }
