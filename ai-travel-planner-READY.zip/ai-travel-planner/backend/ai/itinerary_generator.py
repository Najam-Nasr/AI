"""
ai/itinerary_generator.py
Builds a day-by-day travel itinerary from a route.
"""

from .graph_data import CITY_INFO, TRAVEL_GRAPH


def generate_itinerary(route, days, travelers, hotel_pref, interests, budget):
    """
    Takes a route (list of cities) and generates a full itinerary.
    
    route:      ["Karachi", "Hyderabad", "Lahore"]
    days:       total trip days (int)
    travelers:  number of people (int)
    hotel_pref: "budget", "mid", or "luxury"
    interests:  list like ["adventure", "historical"]
    budget:     total budget in USD
    """
    if not route or len(route) < 2:
        return None

    # Distribute days across cities
    city_days = _distribute_days(route, days)
    
    itinerary = []
    day_counter = 1
    total_cost = 0
    transport_cost = 0

    for i, city in enumerate(route):
        num_days = city_days[i]
        city_data = CITY_INFO.get(city, {})
        hotel_cost = city_data.get("hotel_cost", {}).get(hotel_pref, 40) * travelers
        food_cost = city_data.get("food_cost_per_day", 15) * travelers

        # Get attractions based on interests
        all_attractions = city_data.get("attractions", {})
        selected_attractions = []
        for interest in interests:
            places = all_attractions.get(interest, [])
            selected_attractions.extend(places)
        
        # Remove duplicates while preserving order
        seen = set()
        unique_attractions = []
        for a in selected_attractions:
            if a not in seen:
                seen.add(a)
                unique_attractions.append(a)

        # Fallback if no matching interests
        if not unique_attractions:
            for v in all_attractions.values():
                unique_attractions.extend(v)

        # Calculate transport cost to reach this city
        if i > 0:
            prev_city = route[i - 1]
            for neighbor, cost, hours in TRAVEL_GRAPH.get(prev_city, []):
                if neighbor == city:
                    transport_cost += cost * travelers
                    break

        # Build daily plan for this city
        attractions_per_day = max(1, len(unique_attractions) // num_days)
        
        for d in range(num_days):
            day_attractions = unique_attractions[d * attractions_per_day:(d + 1) * attractions_per_day]
            
            # If last chunk, add remaining
            if d == num_days - 1:
                day_attractions = unique_attractions[d * attractions_per_day:]

            day_cost = hotel_cost + food_cost
            total_cost += day_cost

            itinerary.append({
                "day": day_counter,
                "city": city,
                "hotel_cost": hotel_cost,
                "food_cost": food_cost,
                "day_total": day_cost,
                "activities": day_attractions if day_attractions else ["Free exploration", "Local sightseeing"],
                "morning": day_attractions[0] if len(day_attractions) > 0 else "Check-in and rest",
                "afternoon": day_attractions[1] if len(day_attractions) > 1 else "Explore city center",
                "evening": day_attractions[2] if len(day_attractions) > 2 else "Local food experience",
            })
            day_counter += 1

    grand_total = total_cost + transport_cost
    budget_status = "within_budget" if grand_total <= budget else "over_budget"
    over_by = max(0, grand_total - budget)

    return {
        "route": route,
        "total_days": days,
        "travelers": travelers,
        "itinerary": itinerary,
        "budget_summary": {
            "hotel_total": sum(d["hotel_cost"] for d in itinerary),
            "food_total": sum(d["food_cost"] for d in itinerary),
            "transport_total": transport_cost,
            "grand_total": grand_total,
            "budget": budget,
            "status": budget_status,
            "over_by": over_by,
        }
    }


def _distribute_days(route, total_days):
    """
    Evenly distribute days across cities.
    Always gives at least 1 day per city.
    """
    n = len(route)
    base = total_days // n
    remainder = total_days % n
    days = [base] * n
    for i in range(remainder):
        days[i] += 1
    return days
