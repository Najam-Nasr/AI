@echo off
echo ================================
echo  Starting AI Travel Planner
echo  Frontend (React)
echo ================================
cd /d "%~dp0frontend"
echo Installing packages (first time takes 2-3 mins)...
call npm install
echo.
echo Website starting at http://localhost:3000
echo Keep this window OPEN
echo ================================
npm start
pause
