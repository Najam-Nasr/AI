@echo off
echo ================================
echo  Starting AI Travel Planner
echo  Backend (Flask)
echo ================================
cd /d "%~dp0backend"
if not exist venv (
    echo Creating virtual environment...
    python -m venv venv
)
call venv\Scripts\activate
echo Installing packages...
pip install flask flask-cors python-dotenv requests --quiet
echo.
echo Backend starting at http://localhost:5000
echo Keep this window OPEN
echo ================================
python app.py
pause
